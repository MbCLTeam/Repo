/* Copyright (C) 2023 - GsLKS/IECloud */
/* Contact: suporte@cubie.com.br | trollgames@cubiecloud.ml */
/* IEFW 3.0.0 - Upload Framework for IECloud */

const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');

class upload {
  constructor(serverUrl = 'https://ie-cloud.cubie.com.br') {
    this.serverUrl = serverUrl;
  }

  async uploadFile(filePath) {
    const form = new FormData();
    form.append('file', fs.createReadStream(filePath));

    const config = {
      headers: {
        ...form.getHeaders()
      }
    };

    const { data } = await axios.post(`${this.serverUrl}/v3/upload`, form, config);

    const fileUrl = data.match(/value="(.*?)"/)[1];
    return fileUrl;
  }
}

module.exports = upload;
