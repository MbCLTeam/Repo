const fs = require('fs');

const args = process.argv.slice(2);

if (args.length < 4) {
  console.log('Use: node index --f <arquivo> --txt "<texto>" [--no-spaces|--ns]');
  console.log('Exemplo: node index --f ./app.txt --txt "palavra" --no-spaces');
  process.exit(1);
}

let file, searchText, ignoreSpaces = false;

for (let i = 0; i < args.length; i++) {
  switch (args[i]) {
    case '--f':
    case '-f':
    case '--file':
    case '-file':
      file = args[++i];
      break;
    case '--txt':
    case '-txt':
    case '--text':
    case '-text':
    case '-t':
    case '--t':
      searchText = args[++i];
      break;
    case '--no-spaces':
    case '--ns':
      ignoreSpaces = true;
      break;
    default:
      break;
  }
}

if (!file || !searchText) {
  console.log('Use: node index --f <arquivo> --txt "<texto>" [--no-spaces|--ns]');
  console.log('Exemplo: node index --f ./app.txt --txt "palavra" --no-spaces');
  process.exit(1);
}

fs.readFile(file, 'utf-8', (err, data) => {
  if (err) throw err;

  let regexString = searchText;
  if (ignoreSpaces) {
    regexString = searchText.replace(/\s/g, '');
  }
  const regex = new RegExp(regexString + '.+');
  const result = data.match(regex);

  if (!result) {
    console.log(`Nenhum texto encontrado correspondente a "${searchText}"`);
    process.exit(1);
  }

  fs.writeFile('extraido.txt', result[0], (err) => {
    if (err) throw err;
    console.log(`Texto extraído e salvo em extraido.txt`);
  });
});
