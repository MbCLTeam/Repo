/* Copyright (C) 2023 - GsLKS/IECloud */
/* Contact: suporte@cubie.com.br | trollgames@cubiecloud.ml */
/* IEFW 1.1.0 - Upload Framework for IECloud */
const request = require('request'); const fs = require('fs'); class upload { constructor(serverUrl = 'https://ie-cloud.cubie.com.br') { this.serverUrl = serverUrl; } uploadFile(filePath) { const options = { url: `${this.serverUrl}/upload`, method: 'POST', headers: { 'Content-Type': 'multipart/form-data' }, formData: { file: fs.createReadStream(filePath) } }; return new Promise((resolve, reject) => { request(options, (err, res, body) => { if (err) { reject(err); } else { const fileUrl = body.match(/href="(.*?)"/)[1]; resolve(fileUrl); } }); }); } } module.exports = upload;
